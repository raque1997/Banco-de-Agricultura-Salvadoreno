package com.demo_bank_v1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBankV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
